% vsearch-expected_error(7) version 2.30.0 | vsearch file formats
% Torbjørn Rognes, Tomás Flouri, and Frédéric Mahé
#(../commands/fragments/date.md)

# NAME

expected error --- a summary of the quality of a fastq sequence


# DESCRIPTION

- how to compute?
- interpretation
- properties


# EXAMPLES

(is this section needed?)


# SEE ALSO

(nothing for now)


#(../commands/fragments/footer.md)
