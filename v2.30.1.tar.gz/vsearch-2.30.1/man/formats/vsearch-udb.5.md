% vsearch-udb(5) version 2.30.0 | vsearch file formats
% Torbjørn Rognes, Tomás Flouri, and Frédéric Mahé
#(../commands/fragments/date.md)

# NAME

udb --- a binary format containing fasta sequences and a k-mer index for those sequences


# DESCRIPTION

Hosting a detailled description of the UDB format is important.

- magic number?


# EXAMPLES

(show how to build udb files?)


# SEE ALSO

[`vsearch-fasta(5)`](./vsearch-fasta.5.md), [`vsearch-fastq(5)`](./vsearch-fastq.5.md)


#(../commands/fragments/footer.md)
