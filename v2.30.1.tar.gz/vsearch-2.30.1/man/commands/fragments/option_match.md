`--match` *integer*
: Set the score assigned to a match (i.e. equivalent nucleotides) in
  pairwise alignments. The default value is 2.
