`--minseqlength` *positive integer*
: Discard sequences shorter than *positive integer* (32 nucleotides by default).
