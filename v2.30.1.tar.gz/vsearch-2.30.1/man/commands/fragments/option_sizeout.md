`--sizeout`
: Add abundance annotations to sequence headers when writing fasta or
  fastq files. Add the pattern `;size=integer;`. If option `--sizein`
  is not used, abundance values are set to 1 for all entries. If
  `--sizein` is used, existing abundance annotations are simply
  reported to output files.
