`--log` *filename*
: Write messages to *filename*. Messages include program version,
  start and finish times, elapsed time, amount of memory available,
  maximum amount of memory consumed, number of cores and command line
  options, and if need be, command-specific informational messages,
  warnings, and errors.
