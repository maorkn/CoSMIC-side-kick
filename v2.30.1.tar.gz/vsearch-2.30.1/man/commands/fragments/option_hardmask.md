`--hardmask`
: Replace masked nucleotides with Ns.
