`--relabel_self`
: Replace each sequence header with the sequence itself. To retain
  annotations, use their corresponding options (`--lengthout`,
  `--eeout`, and `--sizeout`). Use `--relabel_keep` to retain old
  sequence identifiers.

