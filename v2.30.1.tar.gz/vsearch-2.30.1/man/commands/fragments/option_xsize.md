`--xsize`
: Strip abundance annotations from sequence headers when writing fasta
  or fastq files. Search for the pattern
  `[>@;]size=integer[;]`. Abundance annotations are added by the
  `--sizeout` option.
