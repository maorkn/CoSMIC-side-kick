`--notrunclabels`
: Retain whole sequence headers in output files. By default, vsearch
  truncates sequence headers at first space or tabulation. This option
  suppresses truncation.
