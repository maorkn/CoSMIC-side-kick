`--threads` *positive non-null integer*
: Command is not multithreaded, option has no effect.
