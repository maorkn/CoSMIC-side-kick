`--output` *filename*
: Write to *filename*, in fasta format.
