`--mismatch` *integer*
: Set the score assigned to a mismatch (i.e. different nucleotides) in
  pairwise alignments. The default value is -4.
