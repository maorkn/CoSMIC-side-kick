`--fasta_width` *positive integer*
: Set maximal width of sequences when writing fasta files. Longer
  sequences are folded and written on several lines. Default width is
  80 nucleotides. Set to zero (0) to suppress folding.
