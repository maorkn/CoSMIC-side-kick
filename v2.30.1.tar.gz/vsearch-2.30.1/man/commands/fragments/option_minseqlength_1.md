`--minseqlength` *positive integer*
: Discard sequences shorter than *positive integer* (1 nucleotide by default).
