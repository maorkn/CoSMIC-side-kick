`--alignwidth` *positive integer*
: Set maximal width of three-way alignments when writing alignments
  with `--alnout`. Default width is 60 nucleotides. Set to zero (0) to
  suppress folding.
