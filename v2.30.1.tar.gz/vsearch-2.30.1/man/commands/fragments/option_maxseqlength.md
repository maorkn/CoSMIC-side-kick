`--maxseqlength` *positive integer*
: Discard sequences longer than *positive integer* (50,000 nucleotides by default).
