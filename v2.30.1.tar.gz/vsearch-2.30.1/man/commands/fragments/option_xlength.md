`--xlength`
: Strip sequence length annotations from sequence headers when writing
  fasta or fastq files. Search for the pattern
  `[>@;]length=integer[;]`. Sequence length annotations are added by
  the `--lengthout` option.
