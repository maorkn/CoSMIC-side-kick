`--chimeras_parents_max` *positive non-null integer*
: Set the maximum number of parent sequences. Accepted values range
  from 2 to 20. Default is 3.
