`--no_progress`
: Suppress the gradually increasing progress indicator normally
  written to the *standard error* `stderr(3)`.
