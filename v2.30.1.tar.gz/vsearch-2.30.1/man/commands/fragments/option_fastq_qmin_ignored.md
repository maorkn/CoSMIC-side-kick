`--fastq_qmin` *positive integer*
: Option is ignored and has no effect.
