`--topn` *positive non-null integer*
: Write only the *n* first entries. The parameter *n* must be greater
  than zero, and is silently ignored if it is greater than the total
  number of entries.
