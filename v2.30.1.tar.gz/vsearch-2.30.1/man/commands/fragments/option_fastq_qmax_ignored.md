`--fastq_qmax` *positive integer*
: Option is ignored and has no effect.
