`--lengthout`
: Add a sequence length annotation (`;length=integer`) to each
  sequence header when writing fasta or fastq files.
