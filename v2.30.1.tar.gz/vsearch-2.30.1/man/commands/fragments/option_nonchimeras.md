`--nonchimeras` *filename*
: Write non-chimeric sequences to *filename*, in fasta format. Output
  order may vary when using multiple threads.
