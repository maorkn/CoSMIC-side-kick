`--chimeras_parts` *positive non-null integer*
: Set the number of parts to divide sequences. Default is (sequence
  length / 100).
