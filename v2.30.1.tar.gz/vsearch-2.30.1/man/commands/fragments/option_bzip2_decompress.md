`--bzip2_decompress`
: Specify that the *input pipe* is streaming data compressed using
  Huffman coding (see `bzip2(1)`). This option is not needed when
  reading from a regular file compressed with bzip2.
