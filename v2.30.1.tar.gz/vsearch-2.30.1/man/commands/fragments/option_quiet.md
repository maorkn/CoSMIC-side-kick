`--quiet`
: Suppress messages to the *standard output* `stdout(3)` and *standard
  error* `stderr(3)`, except for warnings and error messages.
