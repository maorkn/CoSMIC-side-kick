`--gzip_decompress`
: Specify that the *input pipe* is streaming data compressed using
  Lempel-Ziv coding (see `gzip(1)`). This option is not needed when
  reading from a regular file compressed with gzip.
