`--chimeras_length_min` *positive non-null integer*
: Set the minimum length of each chimeric region. Default is 10.
