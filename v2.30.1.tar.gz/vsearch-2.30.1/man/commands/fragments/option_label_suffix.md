`--label_suffix` *string*
: Add the suffix *string* to sequence headers when writing fasta or
  fastq files. For example, with `--label_suffix ";status=healthy"`,
  sequence header '>seq1' becomes '>seq1;status=healthy'.
