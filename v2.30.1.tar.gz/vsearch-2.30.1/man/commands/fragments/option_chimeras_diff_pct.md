`--chimeras_diff_pct` *real*
: Set the maximal mismatch percentage allowed in each chimeric region
  (excluding insertion and deletions). Accepted values range from 0.0
  to 50.0%. Default is 0.0 (no mismatch allowed).
