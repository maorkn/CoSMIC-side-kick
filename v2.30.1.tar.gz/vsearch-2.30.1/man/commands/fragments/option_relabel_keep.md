`--relabel_keep`
: Retain old sequence identifiers by including them at the end of the
  new headers, after a space.
